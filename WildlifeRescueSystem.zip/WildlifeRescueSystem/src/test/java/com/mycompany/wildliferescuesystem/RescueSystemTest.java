/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.wildliferescuesystem;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * 
 * 
 *@author Titus
 * 
 */
class RescueSystemTest {

    // ---------- rescue cost calculations ----------

    @Test
    void injuredAnimalCostIncludesDailyCareAndVetCost() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR101", "Tembo", "African Elephant", "Kruger", "John",
                5, 500, "Broken leg", 8000, false);
        // 5 days x R500 daily care + R8000 vet cost, no surgery
        assertEquals(10500.0, rescue.calculateTotalCost(), 0.001);
    }

    @Test
    void injuredAnimalCostAddsSurgeryFeeWhenRequired() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR102", "Tembo", "African Elephant", "Kruger", "John",
                5, 500, "Broken leg", 8000, true);
        // 5 days x R500 + R8000 vet cost + R5000 surgery fee
        assertEquals(15500.0, rescue.calculateTotalCost(), 0.001);
    }

    @Test
    void orphanedAnimalCostAddsFosterCareFeeWhenRequired() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR201", "Baby Rhino", "White Rhino", "Kruger", "Sarah",
                10, 300, 2, 1500, true);
        // 10 days x R300 + R1500 feeding + R2500 foster care
        assertEquals(7000.0, rescue.calculateTotalCost(), 0.001);
    }

    @Test
    void endangeredSpeciesCostAddsSpecialistTeamFeeWhenRequired() {
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "WR301", "Pangolin", "Temminck's Pangolin", "Limpopo", "David",
                7, 400, "Critically Endangered", 3000, true);
        // 7 days x R400 + R3000 security + R8000 specialist team
        assertEquals(13800.0, rescue.calculateTotalCost(), 0.001);
    }

    @Test
    void injuredAnimalRequiringSurgeryIsCritical() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR103", "Tembo", "African Elephant", "Kruger", "John",
                5, 500, "Broken leg", 8000, true);
        assertEquals(RescuePriority.CRITICAL, rescue.determinePriority());
    }

    @Test
    void veryYoungOrphanIsHighPriority() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR202", "Baby Rhino", "White Rhino", "Kruger", "Sarah",
                10, 300, 2, 1500, false);
        assertEquals(RescuePriority.HIGH, rescue.determinePriority());
    }

    @Test
    void criticallyEndangeredClassificationIsCritical() {
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "WR302", "Pangolin", "Temminck's Pangolin", "Limpopo", "David",
                7, 400, "Critically Endangered", 3000, false);
        assertEquals(RescuePriority.CRITICAL, rescue.determinePriority());
    }

   
    @Test
    void startRescueChangesStatusToInProgress() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR104", "Tembo", "African Elephant", "Kruger", "John",
                5, 500, "Broken leg", 8000, false);
        rescue.startRescue();
        assertEquals(RescueStatus.IN_PROGRESS, rescue.getStatus());
    }

    @Test
    void completeRescueChangesStatusToCompleted() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR105", "Tembo", "African Elephant", "Kruger", "John",
                5, 500, "Broken leg", 8000, false);
        rescue.startRescue();
        rescue.completeRescue();
        assertEquals(RescueStatus.COMPLETED, rescue.getStatus());
    }

    @Test
    void cannotCompleteARescueThatWasNeverStarted() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR106", "Tembo", "African Elephant", "Kruger", "John",
                5, 500, "Broken leg", 8000, false);
        assertThrows(IllegalStateException.class, rescue::completeRescue);
    }

    // searching for an existing rescue case 

    @Test
    void findByIdReturnsTheMatchingCase() {
        RescueManager manager = new RescueManager();
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR107", "Tembo", "African Elephant", "Kruger", "John",
                5, 500, "Broken leg", 8000, false);
        manager.addCase(rescue);

        assertEquals(rescue, manager.findById("WR107"));
        assertEquals(rescue, manager.findById("wr107")); // ID lookup ignores case
    }

    @Test
    void findByIdReturnsNullWhenNoCaseMatches() {
        RescueManager manager = new RescueManager();
        assertNull(manager.findById("DOES_NOT_EXIST"));
    }

    // preventing duplicate Rescue Case IDs 

    @Test
    void addingACaseWithADuplicateIdThrowsException() {
        RescueManager manager = new RescueManager();
        manager.addCase(new InjuredAnimalRescue(
                "WR108", "Tembo", "African Elephant", "Kruger", "John",
                5, 500, "Broken leg", 8000, false));

        assertThrows(IllegalArgumentException.class, () ->
                manager.addCase(new OrphanedAnimalRescue(
                        "WR108", "Baby Rhino", "White Rhino", "Kruger", "Sarah",
                        10, 300, 2, 1500, false)));
    }
}

