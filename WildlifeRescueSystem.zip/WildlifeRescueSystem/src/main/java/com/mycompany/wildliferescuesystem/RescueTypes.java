/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildliferescuesystem;

/**
 *
 * @author Titus
 */
class InjuredAnimalRescue extends RescueCase {
    public static final double SURGERY_FEE = 5000.0;
    public static final double HIGH_VET_COST_THRESHOLD = 10000.0;
 
    private final String injuryDescription;
    private final double veterinaryCost;
    private final boolean surgeryRequired;
 
    public InjuredAnimalRescue(String caseId, String animalName, String species, String location,
                               String ranger, int days, double dailyCost,
                               String injuryDescription, double veterinaryCost, boolean surgeryRequired) {
        super(caseId, animalName, species, location, ranger, days, dailyCost);
        requireText(injuryDescription, "Injury Description");
        requirePositive(veterinaryCost, "Veterinary Treatment Cost");
        this.injuryDescription = injuryDescription.trim();
        this.veterinaryCost = veterinaryCost;
        this.surgeryRequired = surgeryRequired;
    }
 
    @Override public String getRescueType() { return "Injured Animal"; }
 
    @Override
    protected double calculateAdditionalCost() {
        return veterinaryCost + (surgeryRequired ? SURGERY_FEE : 0);
    }
 
    /** Surgery = CRITICAL; expensive treatment = HIGH; otherwise MEDIUM. */
    @Override
    public RescuePriority determinePriority() {
        if (surgeryRequired) return RescuePriority.CRITICAL;
        if (veterinaryCost >= HIGH_VET_COST_THRESHOLD) return RescuePriority.HIGH;
        return RescuePriority.MEDIUM;
    }
 
    @Override
    public String getSpecificDetails() {
        return String.format("Injury: %s | Vet Cost: %s | Surgery Required: %s",
                injuryDescription, formatMoney(veterinaryCost), surgeryRequired ? "Yes" : "No");
    }
}
 
// An orphaned animal: adds estimated age, feeding cost, and foster-care flag. 
class OrphanedAnimalRescue extends RescueCase {
    public static final double FOSTER_CARE_FEE = 2500.0;
 
    private final int ageInMonths;
    private final double feedingCost;
    private final boolean fosterCareRequired;
 
    public OrphanedAnimalRescue(String caseId, String animalName, String species, String location,
                                String ranger, int days, double dailyCost,
                                int ageInMonths, double feedingCost, boolean fosterCareRequired) {
        super(caseId, animalName, species, location, ranger, days, dailyCost);
        requirePositive(ageInMonths, "Estimated Age (Months)");
        requirePositive(feedingCost, "Feeding Cost");
        this.ageInMonths = ageInMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }
 
    @Override public String getRescueType() { return "Orphaned Animal"; }
 
    @Override
    protected double calculateAdditionalCost() {
        return feedingCost + (fosterCareRequired ? FOSTER_CARE_FEE : 0);
    }
 
    // Younger animals are more vulnerable( <=3 months HIGH),( <=12 MEDIUM), older LOW. 
    @Override
    public RescuePriority determinePriority() {
        if (ageInMonths <= 3) return RescuePriority.HIGH;
        if (ageInMonths <= 12) return RescuePriority.MEDIUM;
        return RescuePriority.LOW;
    }
 
    @Override
    public String getSpecificDetails() {
        return String.format("Age: %d months | Feeding Cost: %s | Foster Care Required: %s",
                ageInMonths, formatMoney(feedingCost), fosterCareRequired ? "Yes" : "No");
    }
}
 
//An endangered species will add classification, security cost, and specialist-team flag.
class EndangeredSpeciesRescue extends RescueCase {
    public static final double SPECIALIST_TEAM_FEE = 8000.0;
 
    private final String classification;
    private final double securityCost;
    private final boolean specialistTeamRequired;
 
    public EndangeredSpeciesRescue(String caseId, String animalName, String species, String location,
                                   String ranger, int days, double dailyCost,
                                   String classification, double securityCost, boolean specialistTeamRequired) {
        super(caseId, animalName, species, location, ranger, days, dailyCost);
        requireText(classification, "Conservation Classification");
        requirePositive(securityCost, "Security Cost");
        this.classification = classification.trim();
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }
 
    @Override public String getRescueType() { return "Endangered Species"; }
 
    @Override
    protected double calculateAdditionalCost() {
        return securityCost + (specialistTeamRequired ? SPECIALIST_TEAM_FEE : 0);
    }
 
    /** Critically Endangered or a specialist team = CRITICAL; otherwise HIGH. */
    @Override
    public RescuePriority determinePriority() {
        if (specialistTeamRequired || classification.equalsIgnoreCase("Critically Endangered"))
            return RescuePriority.CRITICAL;
        return RescuePriority.HIGH;
    }
 
    @Override
    public String getSpecificDetails() {
        return String.format("Classification: %s | Security Cost: %s | Specialist Team Required: %s",
                classification, formatMoney(securityCost), specialistTeamRequired ? "Yes" : "No");
    }
}
 





